# reviewReport
A review report plugin for OMP 1.2.0+/OJS 3.1+.

To install this plugin, either use git...

    cd plugins/reports
    git clone https://github.com/pkp/reviewReport

...or download a tarball...

    cd plugins/reports
    tar xzf /path/to/reviewReport.tar.gz

...or find the plugin in the Plugin Gallery within your application, if available.

This should make the report available immediately in your application in `Tools` > `Statistics`.
